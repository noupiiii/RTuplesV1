from turtle import color
from termcolor import colored, cprint

def start():
    cprint('+-------------------------------------------------------------+', 'red')
    cprint('|     ____  ______            __                              |', 'red')
    cprint('|    / __ \/_  __/_  ______  / /__  _____                     |', 'red')
    cprint('|   / /_/ / / / / / / / __ \/ / _ \/ ___/                     |', 'red')
    cprint('|  / _, _/ / / / /_/ / /_/ / /  __(__  )                      |', 'red')
    cprint('| /_/ |_| /_/  \__,_/ .___/_/\___/____/     for PostgreSQL    |', 'red')
    cprint('|                  /_/                                        |', 'red')
    cprint('+-------------------------------------------------------------+', 'red')
    cprint('    - by n0upi', 'magenta')
    cprint('    - Version 1.0', 'green')
    
def randomPersonne():
    cprint('+-------------------------------------------------------------+', 'red')
    cprint('| Générateur de personnes aléatoires                          |', 'red')
    cprint('+-------------------------------------------------------------+', 'red')
    cprint('    - Saisir le nom de la table : ', end='')
    table_name = input('')
    
    cprint('    - Saisir le nombre d\'occurences : ', end='')
    occurences = input('')
    
    cprint('Saisir \'y\' si vous voulez voir apparaitre les tuples suivants dans votre table')
    id_tuple = input('ID : ')
    nom_tuple = input('Nom : ')
    prenom_tuple = input('Prénom : ')
        
    cprint('Nom : ')
    cprint('Prénom : ')
    cprint('Genre : ')
if __name__=='__main__':
    start()
    randomPersonne()
