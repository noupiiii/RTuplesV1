from unicodedata import name
import pandas
import random
# ---------------------------------------
# --- class Name 
# ---------------------------------------
class Name():
    
    name:str = ""
    
    def __init__(self) -> None:
        fileNameRaw = pandas.read_csv('./databases/name.csv')
        fileName = pandas.DataFrame(fileNameRaw)
        
        self.name = fileName.at[random.randint(1,fileName.shape[0]), 'name']
        
    @property
    def getName(self) -> str:
        return self.name
    
    # @property
    # def setName(self, NewName:str):
    #     self.name = NewName.upper()
    
if __name__ == "__main__":
    n = Name()
    print(n.getName)
    # n.setName("test")
    # print(n.getName)