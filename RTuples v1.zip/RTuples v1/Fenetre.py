from ctypes import alignment
from os import stat
from time import daylight
from PyQt6.QtWidgets import *
from PyQt6.QtCore import *
from PyQt6.QtGui import *
import sys
from termcolor import cprint
from Name import Name
from firstName import firstName


WIN_HEIGHT:int = 800
WIN_WIDTH:int = 600


# --- class fenetre ---------------------------
class fenetre(QWidget):
    

    
    def __init__(self):
        app = QApplication(sys.argv)
        
        # Instantiation de la liste contenant les tuples à générer
        self.returnID : bool =False
        self.returnLastName : bool = False
        self.returnFirstName : bool = False
        self.returnGender : bool = False
        
        
        super().__init__()
        self.setWindowTitle('RTuples for PostgreSQL - by n0upi')
        self.setFixedSize(WIN_HEIGHT, WIN_WIDTH)
        

        # ===================================================================
        # LAYOUT PRINCIPAL
        # ===================================================================
        
        self.mainLayout = QHBoxLayout() ; self.setLayout(self.mainLayout)
        
        # ===================================================================
        # LAYOUT GAUCHE
        # ===================================================================
        
        self.leftLayout = QVBoxLayout()
        
        self.leftLayout.addWidget(self.createTitleTable())     
        
        self.leftLayout.addWidget(self.createTitleGroup())   
        
        self.titreCheck = QLabel("Séléctionner les tuples souhaité :")
        self.leftLayout.addWidget(self.titreCheck)
        
        self.leftLayout.addWidget(self.createPersonneGroup())
        self.leftLayout.addWidget(self.createCoordonneesGroup())        
        
        self.generate = QPushButton("Générer")
        self.generate.clicked.connect(self.generation)
        self.leftLayout.addWidget(self.generate)
        
        # ===================================================================
        # LAYOUT DROITE
        # ===================================================================
        # Création de layout de droite
        self.rightLayout = QVBoxLayout()
        
        self.rightLayout.addWidget(self.createReturnGroup())
                
        # ===================================================================
        # LAYOUT APPLICATION
        # ===================================================================
        
        self.mainLayout.addLayout(self.leftLayout)
        self.mainLayout.addLayout(self.rightLayout)

        self.show()
        sys.exit(app.exec())
        # ===================================================================
        # LAYOUT titleTable
        # ===================================================================
    def createTitleTable(self):
        groupBox = QGroupBox("Saisir le nom de la table :")
        groupBox.setMaximumHeight(65)
        self.titleTable = QLineEdit("")
        self.titleTable.setMaximumWidth(75)
        self.titleTable.setText("")
        
        vbox = QVBoxLayout()
        vbox.addWidget(self.titleTable)
        vbox.addStretch(1)
        
        groupBox.setLayout(vbox)
        return groupBox          
        # ===================================================================
        # LAYOUT TITLE
        # ===================================================================
    def createTitleGroup(self):
        groupBox = QGroupBox("Saisir le nombre de tuples souhaité :")
        groupBox.setMaximumHeight(65)
        self.occurences = QLineEdit("")
        self.occurences.setValidator(QIntValidator())
        self.occurences.setMaximumWidth(75)
        self.occurences.setText("10")
        
        vbox = QVBoxLayout()
        vbox.addWidget(self.occurences)
        vbox.addStretch(1)
        
        groupBox.setLayout(vbox)
        return groupBox        
    
        # ===================================================================
        # LAYOUT TABLE NAME
        # ===================================================================
    def createTitleGroupName(self):
        groupBox = QGroupBox("Saisir le nombre de tuples souhaité :")
        groupBox.setMaximumHeight(65)
        self.occurences = QLineEdit("")
        self.occurences.setValidator(QIntValidator())
        self.occurences.setMaximumWidth(75)
        self.occurences.setText("10")
        
        vbox = QVBoxLayout()
        vbox.addWidget(self.occurences)
        vbox.addStretch(1)
        
        groupBox.setLayout(vbox)
        return groupBox
    
        # ===================================================================
        # LAYOUT PERSONNE
        # ===================================================================
    def createPersonneGroup(self):
        groupBox = QGroupBox("Personne :")
        
        self.id = QCheckBox("ID")
        self.id.stateChanged.connect(self.checkBoxChangedActionID)
             
        self.lastName = QCheckBox("Nom")        
        self.lastName.stateChanged.connect(self.checkBoxChangedActionName)
        
        self.firstName = QCheckBox("Prénom")        
        self.firstName.stateChanged.connect(self.checkBoxChangedActionFirstName)
        
        self.gender = QCheckBox("Genre")        
        self.gender.stateChanged.connect(self.checkBoxChangedActionGender)
        self.gender.setCheckable(False)

        hbox = QHBoxLayout()
        
        vbox = QVBoxLayout()
        vbox.addWidget(self.id)
        vbox.addWidget(self.lastName)
        hbox.addWidget(self.firstName)
        
        hbox.addWidget(self.gender)
        vbox.addStretch(1)
        
        vbox.addLayout(hbox)

        groupBox.setLayout(vbox)
        return groupBox

        # ===================================================================
        # LAYOUT RETOUR
        # ===================================================================
    def createReturnGroup(self):
        groupBox = QGroupBox("Résultat : ")
                
        self.resultatBox = QTextEdit()
        self.resultatBox.setReadOnly(True)
        self.resultatBox.setMaximumWidth(500)
        
        self.copyButton = QPushButton("Copier")
        self.copyButton.setMaximumWidth(75)
        
        vbox = QVBoxLayout()
        vbox.addWidget(self.resultatBox)
        vbox.addWidget(self.copyButton)        
        groupBox.setLayout(vbox)
        return groupBox
    
        # ===================================================================
        # LAYOUT COORDONNEES
        # ===================================================================
    def createCoordonneesGroup(self):
        groupBox = QGroupBox("Coordonnées : ")
        
        self.street = QCheckBox("Rue")
        self.Nstreet = QCheckBox("N° de rue")
        self.city = QCheckBox("Ville")
        self.cp = QCheckBox("Code Postal")
        
        vbox = QVBoxLayout()
        vbox.addWidget(self.street)
        vbox.addWidget(self.Nstreet)
        vbox.addWidget(self.city)
        vbox.addWidget(self.cp)
        vbox.addStretch(1)

        
        groupBox.setLayout(vbox)
        
        return groupBox
    
    def generation(self):
        self.returnStr = "INSERT INTO "+str(self.titleTable.text())+" VALUES\n"
        occurencesLOc = int(self.occurences.text())
        
        for i in range(occurencesLOc):
            self.returnStr = self.returnStr + "("
            # for j in range(2):
            if self.returnID == True:
                self.returnStr = self.returnStr + str(i+1) + ","
            if self.returnLastName == True:
                nom = Name()
                self.returnStr = self.returnStr + str(nom.getName) + ","
            if self.returnFirstName == True:
                prenom = firstName()
                self.returnStr = self.returnStr + str(prenom.get_first_name) + ","
            if self.returnGender == True:
                self.returnStr = self.returnStr + str(prenom.get_genre) + ","
                
            self.returnStr = self.returnStr[:-1]
            self.returnStr = self.returnStr +"),\n"
                

            self.resultatBox.setText(str(self.returnStr))


# =================================================================================================
# =================================================================================================
# VERIF CHECK
# =================================================================================================
# =================================================================================================
# ID SELECT
    def checkBoxChangedActionID(self, state):
        if (state == 2):
            self.returnID = True
        else:
            self.returnID = False


# NAME SELECT
    def checkBoxChangedActionName(self, state):
        if (state == 2):
            self.returnLastName = True
        else:
            self.returnLastName = False


# FIRSTNAME SELECT
    def checkBoxChangedActionFirstName(self, state):
        if (state == 2):
            self.returnFirstName = True
            
            # Autorise le choix du genre si un prénom est séléctionné.
            self.gender.setCheckable(True)
        else:
            self.returnFirstName = False
            
            # Cette partie bloque le choix du genre s'il n'y a pas de prénoms.
            self.gender.setChecked(False)
            self.gender.setCheckable(False)
            
# GENDER SELECT
    def checkBoxChangedActionGender(self, state):
        if (state == 2):
            self.returnGender = True
        else:
            self.returnGender = False

# --- main -------------------------------
if __name__ == "__main__":
    f = fenetre()


