from unicodedata import name
import pandas
import random
# ---------------------------------------
# --- class firstName 
# ---------------------------------------
class firstName():
    
    first_name:str = ""
    
    def __init__(self) -> None:
        file_first_name_raw = pandas.read_csv('./databases/first_name.csv')
        file_first_name = pandas.DataFrame(file_first_name_raw)
        
        randomPersonne = random.randint(1,file_first_name.shape[0])
        
        self.first_name = file_first_name.at[randomPersonne, 'first_name']
        self.genre = file_first_name.at[randomPersonne, 'gender']
        
    @property
    def get_first_name(self) -> str:
        return self.first_name
    
    @property
    def get_genre(self) -> str:
        return self.genre
    
if __name__ == "__main__":
    fn = firstName()
    print(fn.get_first_name)
    print(fn.get_genre)